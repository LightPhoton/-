package henu.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;

import henu.bean.Buyer;
import henu.dao.BuyerDao;
import henu.util.DbUtil;

/**
 * Servlet implementation class BuyerServlet
 */
@WebServlet("/BuyerServlet")
public class BuyerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BuyerServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
	 	response.setContentType("text/html;charset=UTF-8");
		String op=request.getParameter("op");
		if("buyerAdd".equals(op)) {
			save(request, response);
		}
		else if("buyerDelete".equals(op)){
			delete(request, response);
		}
		else if("buyerUpdate".equals(op)){
			update(request,response);
		}
		else if("buyerUpdate2".equals(op)){
			update2(request,response);
		}
		else if("buyerSearch".equals(op)){
			search(request,response);
		}
		else if("".equals(op))
		{
			xianshi(request, response);
		}
	}
	
	public void search(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
 		response.setContentType("text/html;charset=UTF-8");
 		String type = request.getParameter("key");
 		String keyword = request.getParameter("value");
 		//默认查询所有的用户信息
 		String sqlSearch ="SELECT * FROM buyer";
 		//如果查询关键字不为空，则重新定义SQL语句
 		if(keyword != "")
 		{
 			sqlSearch ="SELECT * FROM buyer WHERE " +type+ " LIKE'%" + keyword + "%'";
 		}
 		StringBuffer sb = DbUtil.buyerExecuteQuery(sqlSearch);
	 	request.setAttribute("search", sb);
	 	RequestDispatcher dispatcher = request.getRequestDispatcher("page/buyer/buyerAdmin.jsp");
		dispatcher.forward(request, response);
	}
	
	public void update(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
	{
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
 		response.setContentType("text/html;charset=UTF-8");
 		String bno=request.getParameter("bno");
		String bname=request.getParameter("bname");
		String pwd=request.getParameter("pwd");
		String bphone=request.getParameter("bphone");
		String bsex=request.getParameter("bsex");
				
		BuyerDao BuyerDao=new BuyerDao();
		Buyer buyer=new Buyer();
		buyer.setbno(bno);
		buyer.setbname(bname);
		buyer.setpwd(pwd);
		buyer.setbphone(bphone);
		buyer.setbsex(bsex);
		int result=0;
		result=BuyerDao.update(bno,buyer);
		if(result>0){
			JOptionPane.showMessageDialog(null,"修改成功");
			xianshi(request, response);
		}
		else{
			JOptionPane.showMessageDialog(null,"修改失败");
			xianshi(request, response);
		}
	}
	
	public void update2(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
	{
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
 		response.setContentType("text/html;charset=UTF-8");
 		String bno=request.getParameter("bno");
		String bname=request.getParameter("bname");
		String pwd=request.getParameter("pwd");
		String bphone=request.getParameter("bphone");
		String bsex=request.getParameter("bsex");
				
		BuyerDao BuyerDao=new BuyerDao();
		Buyer buyer=new Buyer();
		buyer.setbno(bno);
		buyer.setbname(bname);
		buyer.setpwd(pwd);
		buyer.setbphone(bphone);
		buyer.setbsex(bsex);
		int result=0;
		result=BuyerDao.update(bno,buyer);
		if(result>0){
			JOptionPane.showMessageDialog(null,"修改成功");
			
		}
		else{
			JOptionPane.showMessageDialog(null,"修改失败");
			
		}
	}

	public void delete(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
	{
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
 		response.setContentType("text/html;charset=UTF-8");
		String bno=request.getParameter("bno");
		BuyerDao BuyerDao=new BuyerDao();
		int result = BuyerDao.delete(bno);
		if(result>0)
		{
			JOptionPane.showMessageDialog(null,"删除成功");
			xianshi(request, response);
		}
		else{
			JOptionPane.showMessageDialog(null,"删除失败");
			xianshi(request, response);
		}
	}
	
	public void xianshi(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
	{
		// TODO Auto-generated method stub
			String sqlSearch="SELECT * FROM buyer";
			StringBuffer sb = DbUtil.buyerExecuteQuery(sqlSearch);
		 	request.setAttribute("search", sb);
		 	RequestDispatcher dispatcher = request.getRequestDispatcher("page/buyer/buyerAdmin.jsp");
			dispatcher.forward(request, response);
	}
	
	public void save (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		request.setCharacterEncoding("UTF-8");
 		response.setContentType("text/html;charset=UTF-8");
 		String bno=request.getParameter("bno");
		String bname=request.getParameter("bname");
		String pwd=request.getParameter("pwd");
		String bphone=request.getParameter("bphone");
		String bsex=request.getParameter("bsex");
		
		BuyerDao BuyerDao=new BuyerDao();
		Buyer buyer=new Buyer();
		buyer.setbno(bno);
		buyer.setbname(bname);
		buyer.setpwd(pwd);
		buyer.setbphone(bphone);
		buyer.setbsex(bsex);

		int result=0;
		result=BuyerDao.save(buyer);
		if(result>0){
			JOptionPane.showMessageDialog(null,"添加成功");
			xianshi(request, response);
		}
		else{
			JOptionPane.showMessageDialog(null,"添加失败");
			xianshi(request, response);
		}
		
	}

}
