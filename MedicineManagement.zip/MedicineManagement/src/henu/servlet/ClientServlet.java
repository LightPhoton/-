package henu.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;

import henu.bean.Client;
import henu.dao.ClientDao;
import henu.util.DbUtil;

/**
 * Servlet implementation class Client
 */
@WebServlet("/ClientServlet")
public class ClientServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ClientServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
	 	response.setContentType("text/html;charset=UTF-8");
		String op=request.getParameter("op");
		if("clientAdd".equals(op)) {
			save(request, response);
		}
		else if("clientDelete".equals(op)){
			delete(request, response);
		}
		else if("clientUpdate".equals(op)){
			update(request,response);
		}
		else if("clientSearch".equals(op)){
			search(request,response);
		}
		else if("".equals(op))
		{
			xianshi(request, response);
		}
	}

	public void search(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
 		response.setContentType("text/html;charset=UTF-8");
 		String type = request.getParameter("key");
 		String keyword = request.getParameter("value");
 		//默认查询所有的用户信息
 		String sqlSearch ="SELECT * FROM client";
 		//如果查询关键字不为空，则重新定义SQL语句
 		if(keyword != "")
 		{
 			sqlSearch ="SELECT * FROM client WHERE " +type+ " LIKE'%" + keyword + "%'";
 		}
 		StringBuffer sb = DbUtil.clientExecuteQuery(sqlSearch);
	 	request.setAttribute("search", sb);
	 	RequestDispatcher dispatcher = request.getRequestDispatcher("page/client/clientAdmin.jsp");
		dispatcher.forward(request, response);
	}

	public void update(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
	{
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
 		response.setContentType("text/html;charset=UTF-8");
 		String cno=request.getParameter("cno");
		String cname=request.getParameter("cname");
		String csex=request.getParameter("csex");
		String cage=request.getParameter("cage");
		String caddress=request.getParameter("caddress");
		String cphone=request.getParameter("cphone");
		String csymptom=request.getParameter("csymptom");
		String mno=request.getParameter("mno");
		String ano=request.getParameter("ano");
		String cdate=request.getParameter("cdate");
		String cremark=request.getParameter("cremark");
		
		ClientDao ClientDao=new ClientDao();
		Client client=new Client();
		client.setcno(cno);
		client.setcname(cname);
		client.setcsex(csex);
		client.setcage(cage);
		client.setcaddress(caddress);
		client.setcphone(cphone);
		client.setcsymptom(csymptom);
		client.setmno(mno);
		client.setano(ano);
		client.setcdate(cdate);
		client.setcremark(cremark);
		int result=0;
		result=ClientDao.update(ano,client);
		if(result>0){
			JOptionPane.showMessageDialog(null,"修改成功");
			xianshi(request, response);
		}
		else{
			JOptionPane.showMessageDialog(null,"修改失败");
			xianshi(request, response);
		}
	}

	public void delete(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
	{
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
 		response.setContentType("text/html;charset=UTF-8");
		String cno=request.getParameter("cno");
		ClientDao ClientDao=new ClientDao();
		int result = ClientDao.delete(cno);
		if(result>0)
		{
			JOptionPane.showMessageDialog(null,"删除成功");
			xianshi(request, response);
		}
		else{
			JOptionPane.showMessageDialog(null,"删除失败");
			xianshi(request, response);
		}
	}

	public void xianshi(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
	{
		// TODO Auto-generated method stub
			String sqlSearch="SELECT * FROM client";
			StringBuffer sb = DbUtil.clientExecuteQuery(sqlSearch);
		 	request.setAttribute("search", sb);
		 	RequestDispatcher dispatcher = request.getRequestDispatcher("page/client/clientAdmin.jsp");
			dispatcher.forward(request, response);
	}
	
	public void save (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		request.setCharacterEncoding("UTF-8");
 		response.setContentType("text/html;charset=UTF-8");
 		String cno=request.getParameter("cno");
		String cname=request.getParameter("cname");
		String csex=request.getParameter("csex");
		String cage=request.getParameter("cage");
		String caddress=request.getParameter("caddress");
		String cphone=request.getParameter("cphone");
		String csymptom=request.getParameter("csymptom");
		String mno=request.getParameter("mno");
		String ano=request.getParameter("ano");
		String cdate=request.getParameter("cdate");
		String cremark=request.getParameter("cremark");
		
		ClientDao ClientDao=new ClientDao();
		Client client=new Client();
		client.setcno(cno);
		client.setcname(cname);
		client.setcsex(csex);
		client.setcage(cage);
		client.setcaddress(caddress);
		client.setcphone(cphone);
		client.setcsymptom(csymptom);
		client.setmno(mno);
		client.setano(ano);
		client.setcdate(cdate);
		client.setcremark(cremark);
		int result=0;
		result=ClientDao.save(client);
		if(result>0){
			JOptionPane.showMessageDialog(null,"添加成功");
			xianshi(request, response);
		}
		else{
			JOptionPane.showMessageDialog(null,"添加失败");
			xianshi(request, response);
		}
		
	}
}
