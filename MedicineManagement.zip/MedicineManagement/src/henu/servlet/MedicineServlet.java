package henu.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;

import henu.bean.Medicine;
import henu.dao.MedicineDao;
import henu.util.DbUtil;

/**
 * Servlet implementation class MedicineServlet
 */
@WebServlet("/MedicineServlet")
public class MedicineServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MedicineServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
	 	response.setContentType("text/html;charset=UTF-8");
		String op=request.getParameter("op");
		if("medicineAdd".equals(op)) {
			save(request, response);
		}
		else if("medicineDelete".equals(op)){
			delete(request, response);
		}
		else if("medicineUpdate".equals(op)){
			update(request,response);
		}
		else if("medicineSearch".equals(op)){
			search(request,response);
		}
		else if("".equals(op))
		{
			xianshi(request, response);
		}
	}

	public void search(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
 		response.setContentType("text/html;charset=UTF-8");
 		String type = request.getParameter("key");
 		String keyword = request.getParameter("value");
 		//默认查询所有的用户信息
 		String sqlSearch ="SELECT * FROM medicine";
 		//如果查询关键字不为空，则重新定义SQL语句
 		if(keyword != "")
 		{
 			sqlSearch ="SELECT * FROM medicine WHERE " +type+ " LIKE'%" + keyword + "%'";
 		}
 		StringBuffer sb = DbUtil.medicineExecuteQuery(sqlSearch);
	 	request.setAttribute("search", sb);
	 	RequestDispatcher dispatcher = request.getRequestDispatcher("page/medicine/medicineAdmin.jsp");
		dispatcher.forward(request, response);
	}

	public void update(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
	{
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
 		response.setContentType("text/html;charset=UTF-8");
 		String mno=request.getParameter("mno");
		String mname=request.getParameter("mname");
		String mmode=request.getParameter("mmode");
		String mefficacy=request.getParameter("mefficacy");
		
		MedicineDao MedicineDao=new MedicineDao();
		Medicine medicine=new Medicine();
		medicine.setmno(mno);
		medicine.setmname(mname);
		medicine.setmmode(mmode);
		medicine.setmefficacy(mefficacy);
		int result=0;
		result=MedicineDao.update(mno,medicine);
		if(result>0){
			JOptionPane.showMessageDialog(null,"修改成功");
			xianshi(request, response);
		}
		else{
			JOptionPane.showMessageDialog(null,"修改失败");
			xianshi(request, response);
		}
	}

	public void delete(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
	{
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
 		response.setContentType("text/html;charset=UTF-8");
		String mno=request.getParameter("mno");
		MedicineDao MedicineDao=new MedicineDao();
		int result = MedicineDao.delete(mno);
		if(result>0)
		{
			JOptionPane.showMessageDialog(null,"删除成功");
			xianshi(request, response);
		}
		else{
			JOptionPane.showMessageDialog(null,"删除失败");
			xianshi(request, response);
		}
	}
	
	public void xianshi(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
	{
		// TODO Auto-generated method stub
			String sqlSearch="SELECT * FROM medicine";
			StringBuffer sb = DbUtil.medicineExecuteQuery(sqlSearch);
		 	request.setAttribute("search", sb);
		 	RequestDispatcher dispatcher = request.getRequestDispatcher("page/medicine/medicineAdmin.jsp");
			dispatcher.forward(request, response);
	}
	
	public void save (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		request.setCharacterEncoding("UTF-8");
 		response.setContentType("text/html;charset=UTF-8");
 		String mno=request.getParameter("mno");
		String mname=request.getParameter("mname");
		String mmode=request.getParameter("mmode");
		String mefficacy=request.getParameter("mefficacy");
		
		MedicineDao MedicineDao=new MedicineDao();
		Medicine medicine=new Medicine();
		medicine.setmno(mno);
		medicine.setmname(mname);
		medicine.setmmode(mmode);
		medicine.setmefficacy(mefficacy);
		int result=0;
		result=MedicineDao.save(medicine);
		if(result>0){
			JOptionPane.showMessageDialog(null,"添加成功");
			xianshi(request, response);
		}
		else{
			JOptionPane.showMessageDialog(null,"添加失败");
			xianshi(request, response);
		}
		
	}
}
