package henu.servlet;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;

import henu.bean.Agency;
import henu.dao.AgencyDao;
import henu.util.DbUtil;

/**
 * Servlet implementation class AgencyServlet
 */
@WebServlet(name = "AgencyServlet")
public class AgencyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AgencyServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
	 	response.setContentType("text/html;charset=UTF-8");
		String op=request.getParameter("op");
		if("agencyAdd".equals(op)) {
			save(request, response);
		}
		else if("agencyDelete".equals(op)){
			delete(request, response);
		}
		else if("agencyUpdate".equals(op)){
			update(request,response);
		}
		else if("agencyUpdate2".equals(op)){
			update2(request,response);
		}
		else if("agencySearch".equals(op)){
			search(request,response);
		}
		else if("".equals(op))
		{
			xianshi(request, response);
		}
	}
	
	
	
	public void search(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
 		response.setContentType("text/html;charset=UTF-8");
 		String type = request.getParameter("key");
 		String keyword = request.getParameter("value");
 		//默认查询所有的用户信息
 		String sqlSearch ="SELECT * FROM agency";
 		//如果查询关键字不为空，则重新定义SQL语句
 		if(keyword != "")
 		{
 			sqlSearch ="SELECT * FROM agency WHERE " +type+ " LIKE'%" + keyword + "%'";
 		}
 		StringBuffer sb = DbUtil.agencyExecuteQuery(sqlSearch);
	 	request.setAttribute("search", sb);
	 	RequestDispatcher dispatcher = request.getRequestDispatcher("page/agency/agencyAdmin.jsp");
		dispatcher.forward(request, response);
	}

	public void update(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
	{
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
 		response.setContentType("text/html;charset=UTF-8");
 		String ano=request.getParameter("ano");
		String aname=request.getParameter("aname");
		String pwd=request.getParameter("pwd");
		String aphone=request.getParameter("aphone");
		String asex=request.getParameter("asex");
		String aremark=request.getParameter("aremark");
		
		AgencyDao AgencyDao=new AgencyDao();
		Agency agency=new Agency();
		agency.setano(ano);
		agency.setaname(aname);
		agency.setpwd(pwd);
		agency.setaphone(aphone);
		agency.setasex(asex);
		agency.setaremark(aremark);
		int result=0;
		result=AgencyDao.update(ano,agency);
		if(result>0){
			JOptionPane.showMessageDialog(null,"修改成功");
			xianshi(request, response);
		}
		else{
			JOptionPane.showMessageDialog(null,"修改失败");
			xianshi(request, response);
		}
	}
	
	public void update2(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
	{
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
 		response.setContentType("text/html;charset=UTF-8");
 		String ano=request.getParameter("ano");
		String aname=request.getParameter("aname");
		String pwd=request.getParameter("pwd");
		String aphone=request.getParameter("aphone");
		String asex=request.getParameter("asex");
		String aremark=request.getParameter("aremark");
		
		AgencyDao AgencyDao=new AgencyDao();
		Agency agency=new Agency();
		agency.setano(ano);
		agency.setaname(aname);
		agency.setpwd(pwd);
		agency.setaphone(aphone);
		agency.setasex(asex);
		agency.setaremark(aremark);
		int result=0;
		result=AgencyDao.update(ano,agency);
		if(result>0){
			JOptionPane.showMessageDialog(null,"修改成功");
		}
		else{
			JOptionPane.showMessageDialog(null,"修改失败");
		}
	}

	public void delete(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
	{
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
 		response.setContentType("text/html;charset=UTF-8");
		String ano=request.getParameter("ano");
		AgencyDao AgencyDao=new AgencyDao();
		int result = AgencyDao.delete(ano);
		if(result>0)
		{
			JOptionPane.showMessageDialog(null,"删除成功");
			xianshi(request, response);
		}
		else{
			JOptionPane.showMessageDialog(null,"删除失败");
			xianshi(request, response);
		}
	}

	public void xianshi(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
	{
		// TODO Auto-generated method stub
			String sqlSearch="SELECT * FROM agency";
			StringBuffer sb = DbUtil.agencyExecuteQuery(sqlSearch);
		 	request.setAttribute("search", sb);
		 	RequestDispatcher dispatcher = request.getRequestDispatcher("page/agency/agencyAdmin.jsp");
			dispatcher.forward(request, response);
	}

	public void save (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		request.setCharacterEncoding("UTF-8");
 		response.setContentType("text/html;charset=UTF-8");
 		String ano=request.getParameter("ano");
		String aname=request.getParameter("aname");
		String pwd=request.getParameter("pwd");
		String aphone=request.getParameter("aphone");
		String asex=request.getParameter("asex");
		String aremark=request.getParameter("aremark");
		
		AgencyDao AgencyDao=new AgencyDao();
		Agency agency=new Agency();
		agency.setano(ano);
		agency.setaname(aname);
		agency.setpwd(pwd);
		agency.setaphone(aphone);
		agency.setasex(asex);
		agency.setaremark(aremark);
		int result=0;
		result=AgencyDao.save(agency);
		if(result>0){
			JOptionPane.showMessageDialog(null,"添加成功");
			xianshi(request, response);
		}
		else{
			JOptionPane.showMessageDialog(null,"添加失败");
			xianshi(request, response);
		}
	}

}
