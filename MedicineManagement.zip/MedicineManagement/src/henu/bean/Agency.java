package henu.bean;

import henu.util.DbUtil;
import java.sql.*;
import java.util.ArrayList;

public class Agency
{
	private String ano;
	private String aname;
	private String pwd;
	private String asex;
	private String aphone;
	private String aremark;
	
	/*
	 * setter和getter方法
	 */
	public String getano() {
		return ano;
	}
	
	public void setano(String ano) {
		this.ano = ano;
	}

	public String getaname() {
		return aname;
	}

	public void setaname(String aname) {
		this.aname = aname;
	}
	
	public String getpwd() {
		return pwd;
	}

	public void setpwd(String pwd) {
		this.pwd = pwd;
	}
	
	public String getasex() {
		return asex;
	}

	public void setasex(String asex) {
		this.asex = asex;
	}

	public String getaphone() {
		return aphone;
	}
	
	public void setaphone(String aphone) {
		this.aphone = aphone;
	}
	
	public String getaremark() {
		return aremark;
	}

	public void setaremark(String aremark) {
		this.aremark = aremark;
	}
	
	/*
	 * 用户注册功能
	 * @param user
	 * @return 注册成功返回true，否则返回false
	 */
	public boolean regist(Agency agency)
	{
		String sql = "INSERT INTO agency(ano,aname,pwd,asex,aphone," +
				"aremark) VALUES (?,?,?,?,?)";
		
		int result = 0;
		//调用henu.util.DbUtil工具类方法创建PreparedStatement对象
		try{
			PreparedStatement ps = DbUtil.executePreparedStatement(sql);
			ps.setString(1,agency.getano());
			ps.setString(2,agency.getaname());
			ps.setString(3,agency.getpwd());
			ps.setString(4,agency.getasex());
			ps.setString(5,agency.getaphone());
			ps.setString(6,agency.getaremark());
			
			//执行SQL语句
			result = ps.executeUpdate();
			ps.close();
			}catch(SQLException e) {
				e.printStackTrace();
		}
		if(result>0)
			return true;
		else
			return false;
	}
	
	public ArrayList<Agency> findAllAgency(){
		ArrayList<Agency> AgencyList=new ArrayList<Agency>();
		String sqlSearch = "SELECT * FROM agency";
		ResultSet rs = null;
		rs = DbUtil.executeQuery(sqlSearch);
		try{
		while(rs.next())
		{
			 Agency tem= new Agency();
			 tem.setano(rs.getString("ano"));
			 tem.setaname(rs.getString("aname"));
			 tem.setpwd(rs.getString("pwd"));
			 tem.setasex(rs.getString("asex"));
			 tem.setaphone(rs.getString("aphone"));
			 tem.setaremark(rs.getString("aremark"));
			 AgencyList.add(tem);	 
		}
		DbUtil.close();
		}catch(SQLException e)
		{
			e.printStackTrace();	
		}			
		return AgencyList;		
	}
	
	@Override
	public String toString()
	{
		String S = " ano = ["+ano+"]  aname = ["+aname+"]  asex = ["
	+asex+"] "+ " aphone = ["+aphone+"]"+ " aremark = ["+aremark+"]";
		return S;
	}
}
