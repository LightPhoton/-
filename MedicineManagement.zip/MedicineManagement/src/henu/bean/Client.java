package henu.bean;

import henu.util.DbUtil;
import java.sql.*;
import java.util.ArrayList;

public class Client
{
	private String cno;
	private String cname;
	private String csex;
	private String cage;
	private String caddress;
	private String cphone;
	private String csymptom;
	private String mno;
	private String ano;
	private String cdate;
	private String cremark;
	/*
	 * setter和getter方法
	 */
	public String getcno() {
		return cno;
	}

	public void setcno(String cno) {
		this.cno = cno;
	}

	public String getcname() {
		return cname;
	}

	public void setcname(String cname) {
		this.cname = cname;
	}

	public String getcsex() {
		return csex;
	}

	public void setcsex(String csex) {
		this.csex = csex;
	}

	public String getcage() {
		return cage;
	}

	public void setcage(String cage) {
		this.cage = cage;
	}

	public String getcaddress() {
		return caddress;
	}

	public void setcaddress(String caddress) {
		this.caddress = caddress;
	}
	
	public String getcphone() {
		return cphone;
	}
	
	public void setcphone(String cphone) {
		this.cphone = cphone;
	}
	
	public String getcsymptom() {
		return csymptom;
	}
	public void setcsymptom(String csymptom) {
		  this.csymptom = csymptom;
	}
	
	public String getmno() {
		return mno;
	}
	
	public void setmno(String mno) {
		this.mno = mno;
	}
	
	public String getano() {
		return ano;
	}
	
	public void setano(String ano) {
		this.ano = ano;
	}
	
	public String getcdate() {
		return cdate;
	}

	public void setcdate(String cdate) {
		this.cdate = cdate;
	}
	
	public String getcremark() {
		return cremark;
	}

	public void setcremark(String cremark) {
		this.cremark = cremark;
	}
	
	/*
	 * 顾客信息保存
	 * @param client
	 * @return 注册成功返回true，否则返回false
	 */
	public boolean clientSave(Client client)
	{
		String sql = "INSERT INTO client(cno,cname,csex,cage,caddress,cphone," +
				"csymptom,mno,ano,cdate,cremark) VALUES (?,?,?,?,?,?,?,?,?,?,?)";
		
		int result = 0;
		//调用henu.util.DbUtil工具类方法创建PreparedStatement对象
		try{
			PreparedStatement ps = DbUtil.executePreparedStatement(sql);
			ps.setString(1,client.getcno());
			ps.setString(2,client.getcname());
			ps.setString(3,client.getcsex());
			ps.setString(4,client.getcage());
			ps.setString(5,client.getcaddress());
			ps.setString(6,client.getcphone());
			ps.setString(7,client.getcsymptom());
			ps.setString(8,client.getmno());
			ps.setString(9,client.getano());
			ps.setString(10,client.getcdate());
			ps.setString(11,client.getcremark());
			
			//执行SQL语句
			result = ps.executeUpdate();
			ps.close();
			}catch(SQLException e) {
				e.printStackTrace();
		}
		if(result>0)
			return true;
		else
			return false;
	}
	
	public ArrayList<Client> findAll(){
		ArrayList<Client> ClientList=new ArrayList<Client>();
		String sqlSearch = "SELECT * FROM client";
		ResultSet rs = null;
		rs = DbUtil.executeQuery(sqlSearch);
		try{
		while(rs.next())
		{
			 Client tem= new Client();
			 tem.setcno(rs.getString("cno"));
			 tem.setcname(rs.getString("cname"));
			 tem.setcsex(rs.getString("csex"));
			 tem.setcage(rs.getString("cage"));			 
			 tem.setcaddress(rs.getString("caddress"));
			 tem.setcphone(rs.getString("phone"));
			 tem.setcsymptom(rs.getString("csymptom"));
			 tem.setmno(rs.getString("mno"));
			 tem.setano(rs.getString("ano"));
			 tem.setcdate(rs.getString("cdate"));
			 tem.setcremark(rs.getString("cremark"));
			 ClientList.add(tem);	 
		}
		DbUtil.close();
		}catch(SQLException e)
		{
			e.printStackTrace();	
		}			
		return ClientList;		
	}
	
	@Override
	public String toString()
	{
		String S = " cno = ["+cno+"]  cname = ["+cname+"]  csex = ["
				+csex+"]  cage = ["+cage+"]   caddress = ["+caddress+"]"
				+ " cphone = ["+cphone+"]" + " csymptom = ["+csymptom+"] "
				+ " mno = ["+mno+"]" + " ano = ["+ano+"]"
				+ " cdate = [" +cdate+"] " + " cremark = ["+cremark+"]";
		return S;
	}
}
