package henu.bean;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import henu.util.DbUtil;

public class Medicine
{
	private String mno;
	private String mname;
	private String mmode;
	private String mefficacy;

	/*
	 * setter和getter方法
	 */
	public String getmno() {
		return mno;
	}
	
	public void setmno(String mno) {
		this.mno = mno;
	}

	public String getmname() {
		return mname;
	}

	public void setmname(String mname) {
		this.mname = mname;
	}

	public String getmmode() {
		return mmode;
	}

	public void setmmode(String mmode) {
		this.mmode = mmode;
	}
	
	public String getmefficacy() {
		return mefficacy;
	}

	public void setmefficacy(String mefficacy) {
		this.mefficacy = mefficacy;
	}
	
	/*
	 * 用户注册功能
	 * @param user
	 * @return 注册成功返回true，否则返回false
	 */
	public boolean regist(Medicine medicine)
	{
		String sql = "INSERT INTO medicine(mno,mname,mmode,aphone," +
				"mefficacy) VALUES (?,?,?,?)";
		
		int result = 0;
		//调用henu.util.DbUtil工具类方法创建PreparedStatement对象
		try{
			PreparedStatement ps = DbUtil.executePreparedStatement(sql);
			ps.setString(1,medicine.getmno());
			ps.setString(2,medicine.getmname());
			ps.setString(3,medicine.getmmode());
			ps.setString(5,medicine.getmefficacy());
			
			//执行SQL语句
			result = ps.executeUpdate();
			ps.close();
			}catch(SQLException e) {
				e.printStackTrace();
		}
		if(result>0)
			return true;
		else
			return false;
	}
	
	public ArrayList<Medicine> findAllMedicine(){
		ArrayList<Medicine> MedicineList=new ArrayList<Medicine>();
		String sqlSearch = "SELECT * FROM medicine";
		ResultSet rs = null;
		rs = DbUtil.executeQuery(sqlSearch);
		try{
		while(rs.next())
		{
			 Medicine tem= new Medicine();
			 tem.setmno(rs.getString("mno"));
			 tem.setmname(rs.getString("mname"));
			 tem.setmmode(rs.getString("mmode"));
			 tem.setmefficacy(rs.getString("mefficacy"));
			 MedicineList.add(tem);	 
		}
		DbUtil.close();
		}catch(SQLException e)
		{
			e.printStackTrace();	
		}			
		return MedicineList;		
	}
	
	@Override
	public String toString()
	{
		String S = " mno = ["+mno+"]  mname = ["+mname+"]  mmode = ["
	+mmode+"] "+ " mefficacy = ["+mefficacy+"]";
		return S;
	}
}
