package henu.bean;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import henu.util.DbUtil;

public class Buyer
{
	private String bno;
	private String bname;
	private String pwd;
	private String bsex;
	private String bphone;

	
	/*
	 * setter和getter方法
	 */
	public String getbno() {
		return bno;
	}
	
	public void setbno(String bno) {
		this.bno = bno;
	}

	public String getbname() {
		return bname;
	}

	public void setbname(String bname) {
		this.bname = bname;
	}
	
	public String getpwd() {
		return pwd;
	}

	public void setpwd(String pwd) {
		this.pwd = pwd;
	}

	public String getbsex() {
		return bsex;
	}

	public void setbsex(String bsex) {
		this.bsex = bsex;
	}

	public String getbphone() {
		return bphone;
	}
	
	public void setbphone(String bphone) {
		this.bphone = bphone;
	}
	

	/*
	 * 用户注册功能
	 * @param user
	 * @return 注册成功返回true，否则返回false
	 */
	public boolean regist(Buyer buyer)
	{
		String sql = "INSERT INTO buyer(bno,bname,pwd,bsex,bphone," +
				" VALUES (?,?,?,?,?)";
		
		int result = 0;
		//调用henu.util.DbUtil工具类方法创建PreparedStatement对象
		try{
			PreparedStatement ps = DbUtil.executePreparedStatement(sql);
			ps.setString(1,buyer.getbno());
			ps.setString(2,buyer.getbname());
			ps.setString(3,buyer.getpwd());
			ps.setString(4,buyer.getbsex());
			ps.setString(5,buyer.getbphone());
			
			//执行SQL语句
			result = ps.executeUpdate();
			ps.close();
			}catch(SQLException e) {
				e.printStackTrace();
		}
		if(result>0)
			return true;
		else
			return false;
	}
	
	public ArrayList<Buyer> findAllBuyer(){
		ArrayList<Buyer> BuyerList=new ArrayList<Buyer>();
		String sqlSearch = "SELECT * FROM buyer";
		ResultSet rs = null;
		rs = DbUtil.executeQuery(sqlSearch);
		try{
		while(rs.next())
		{
			 Buyer tem= new Buyer();
			 tem.setbno(rs.getString("bno"));
			 tem.setbname(rs.getString("bname"));
			 tem.setpwd(rs.getString("pwd"));
			 tem.setbsex(rs.getString("bsex"));
			 tem.setbphone(rs.getString("bphone"));
			 BuyerList.add(tem);	 
		}
		DbUtil.close();
		}catch(SQLException e)
		{
			e.printStackTrace();	
		}			
		return BuyerList;		
	}
	
	@Override
	public String toString()
	{
		String S = " bno = ["+bno+"]  bname = ["+bname+"]  bsex = ["
	+bsex+"] "+ " bphone = ["+bphone+"]";
		return S;
	}
}
