package henu.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import henu.bean.Medicine;
import henu.util.DbUtil;

public class MedicineDao
{
	public int save(Medicine medicine) {
		String sql = "INSERT INTO medicine(mno,mname,"
				+ "mmode,"+ "mefficacy) "+ "VALUES (?,?,?,?)";
		PreparedStatement ps = DbUtil.executePreparedStatement(sql);
		int result = 0;
		try {
			ps.setString(1,medicine.getmno());
			ps.setString(2,medicine.getmname());
			ps.setString(3,medicine.getmmode());
			ps.setString(4,medicine.getmefficacy());
			result = ps.executeUpdate();
		}catch (SQLException e) {
			e.printStackTrace();
		}
		DbUtil.close();
		return result;
	}
	
	public int delete(String mno) {
		String sql = "DELETE FROM medicine WHERE mno = '"
				+ mno + "'";
		int result = 0;
		result = DbUtil.executeUpdate(sql);
		DbUtil.close();
		return result;
	}
	
	public int update(String mno,Medicine medicine) {
		String sql = "UPDATE medicine SET mname = ?,mmode = ?,"
				+ " mefficacy = ? WHERE mno = ?";
		PreparedStatement ps = DbUtil.executePreparedStatement(sql);
		int result = 0;
		try {
			
			ps.setString(1,medicine.getmname());
			ps.setString(2,medicine.getmmode());
			ps.setString(3,medicine.getmefficacy());
			ps.setString(4,medicine.getmno());
			result = ps.executeUpdate();
		}catch (SQLException e) {
			e.printStackTrace();
		}
		DbUtil.close();
		return result;
	}
	
	public Medicine findBymname(String mname) {
		String sql = "SELECT * FROM medicine WHERE mname = '"
				+ mname + "'";
		Medicine medicine =new Medicine();
		ResultSet rs = DbUtil.executeQuery(sql);
		try {
			if(rs.next())
			{
				medicine.setmno(rs.getString("mno"));
				medicine.setmname(rs.getString("mname"));
				medicine.setmmode(rs.getString("mmode"));
				medicine.setmefficacy(rs.getString("mefficacy"));
			}
		}catch (SQLException e) {
			e.printStackTrace();
		}
		DbUtil.close();
		return medicine;
	}
	
	
	public ArrayList<Medicine> findAll(){
		ArrayList<Medicine> MedicineList=new ArrayList<Medicine>();
		String sqlSearch = "SELECT * FROM medicine ORDER BY mname";
		ResultSet rs = null;
		rs = DbUtil.executeQuery(sqlSearch);
		try{
		while(rs.next())
		{
			 Medicine tem= new Medicine();
			 tem.setmno(rs.getString("mno"));
			 tem.setmname(rs.getString("mname"));
			 tem.setmmode(rs.getString("mmode"));
			 tem.setmefficacy(rs.getString("mefficacy"));
			 MedicineList.add(tem);
		}
		DbUtil.close();
		}catch(SQLException e)
		{
			e.printStackTrace();	
		}
		return MedicineList;		
	}
}
