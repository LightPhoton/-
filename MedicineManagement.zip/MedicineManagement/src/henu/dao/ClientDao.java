package henu.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import henu.bean.Client;
import henu.util.DbUtil;

public class ClientDao
{
	public int save(Client client) {
		String sql = "INSERT INTO client(cno,cname,"
				+ "csex,cage,caddress,cphone,"
				+ "csymptom,mno,ano,cdate,cremark)"
				+ "VALUES (?,?,?,?,?,?,?,?,?,?,?)";
		PreparedStatement ps = DbUtil.executePreparedStatement(sql);
		int result = 0;
		try {
			ps.setString(1,client.getcno());
			ps.setString(2,client.getcname());
			ps.setString(3,client.getcsex());
			ps.setString(4,client.getcage());
			ps.setString(5,client.getcaddress());
			ps.setString(6,client.getcphone());
			ps.setString(7,client.getcsymptom());
			ps.setString(8,client.getmno());
			ps.setString(9,client.getano());
			ps.setString(10,client.getcdate());
			ps.setString(11,client.getcremark());
			result = ps.executeUpdate();
		}catch (SQLException e) {
			e.printStackTrace();
		}
		DbUtil.close();
		return result;
	}
	
	public int delete(String cno) {
		String sql = "DELETE FROM client WHERE cno = '"
				+ cno + "'";
		int result = 0;
		result = DbUtil.executeUpdate(sql);
		DbUtil.close();
		return result;
	}
	
	public int update(String cno,Client client) {
		String sql = "UPDATE client SET cname = ?,csex = ?,cage = ?,"
				+ " caddress = ?,cphone = ?,csymptom = ?,mno = ?,"
				+ " ano = ?, cdate = ?, cremark = ? WHERE cno = ?";
		PreparedStatement ps = DbUtil.executePreparedStatement(sql);
		int result = 0;
		try {
			
			ps.setString(1,client.getcname());
			ps.setString(2,client.getcsex());
			ps.setString(3,client.getcage());
			ps.setString(4,client.getcaddress());
			ps.setString(5,client.getcphone());
			ps.setString(6,client.getcsymptom());
			ps.setString(7,client.getmno());
			ps.setString(8,client.getano());
			ps.setString(9,client.getcdate());
			ps.setString(10,client.getcremark());
			ps.setString(11,client.getcno());
			result = ps.executeUpdate();
			//System.out.println("result:" + result);
		}catch (SQLException e) {
			e.printStackTrace();
		}
		DbUtil.close();
		return result;
	}
	
	public Client findByCname(String cno) {
		String sql = "SELECT * FROM client WHERE cno = '"
				+ cno + "'";
		Client client =new Client();
		ResultSet rs = DbUtil.executeQuery(sql);
		try {
			if(rs.next())
			{
				client.setcno(rs.getString("cno"));
				client.setcname(rs.getString("cname"));
				client.setcsex(rs.getString("csex"));
				client.setcage(rs.getString("cage"));
				client.setcaddress(rs.getString("caddress"));
				client.setcphone(rs.getString("cphone"));
				client.setcsymptom(rs.getString("csymptom"));
				client.setmno(rs.getString("mno"));
				client.setano(rs.getString("ano"));
				client.setcdate(rs.getString("cdate"));
				client.setcremark(rs.getString("cremark"));
			}
		}catch (SQLException e) {
			e.printStackTrace();
		}
		DbUtil.close();
		return client;
	}
	
	
	public ArrayList<Client> findAllClient(){
		ArrayList<Client> ClientList=new ArrayList<Client>();
		String sqlSearch = "SELECT * FROM client ORDER BY cname";
		ResultSet rs = null;
		rs = DbUtil.executeQuery(sqlSearch);
		try{
		while(rs.next())
		{
			 Client tem= new Client();
			 tem.setcno(rs.getString("cno"));
			 tem.setcname(rs.getString("cname"));
			 tem.setcsex(rs.getString("csex"));
			 tem.setcage(rs.getString("cage"));			 
			 tem.setcaddress(rs.getString("caddress"));
			 tem.setcphone(rs.getString("phone"));
			 tem.setcsymptom(rs.getString("csymptom"));
			 tem.setmno(rs.getString("mno"));
			 tem.setano(rs.getString("ano"));
			 tem.setcdate(rs.getString("cdate"));
			 tem.setcremark(rs.getString("cremark"));
			 ClientList.add(tem);	 
		}
		DbUtil.close();
		}catch(SQLException e)
		{
			e.printStackTrace();	
		}			
		return ClientList;		
	}
	
}
