package henu.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import henu.bean.Agency;
import henu.util.DbUtil;

public class AgencyDao
{
	public int save(Agency agency) {
		String sql = "INSERT INTO agency(ano,aname,"
				+ "pwd,asex,aphone,"+ "aremark)"
				+ "VALUES (?,?,?,?,?,?)";
		PreparedStatement ps = DbUtil.executePreparedStatement(sql);
		int result = 0;
		try {
			ps.setString(1,agency.getano());
			ps.setString(2,agency.getaname());
			ps.setString(3,agency.getpwd());
			ps.setString(4,agency.getasex());
			ps.setString(5,agency.getaphone());
			ps.setString(6,agency.getaremark());
			result = ps.executeUpdate();
		}catch (SQLException e) {
			e.printStackTrace();
		}
		DbUtil.close();
		return result;
	}
	
	public int delete(String ano) {
		String sql = "DELETE FROM agency WHERE ano = '"
				+ ano + "'";
		int result = 0;
		result = DbUtil.executeUpdate(sql);
		DbUtil.close();
		return result;
	}
	
	public int update(String ano,Agency agency) {
		String sql = "UPDATE agency SET aname = ?,pwd = ?,asex = ?,"
				+ " aphone = ?," + " aremark = ? WHERE ano = ?";
		PreparedStatement ps = DbUtil.executePreparedStatement(sql);
		int result = 0;
		try {
			ps.setString(1,agency.getaname());
			ps.setString(2,agency.getpwd());
			ps.setString(3,agency.getasex());
			ps.setString(4,agency.getaphone());
			ps.setString(5,agency.getaremark());
			ps.setString(6,agency.getano());
			result = ps.executeUpdate();
			//System.out.println("result:" + result);
		}catch (SQLException e) {
			e.printStackTrace();
		}
		DbUtil.close();
		return result;
	}
	
	public Agency findByaname(String aname) {
		String sql = "SELECT * FROM agency WHERE aname = '"
				+ aname + "'";
		Agency agency =new Agency();
		ResultSet rs = DbUtil.executeQuery(sql);
		try {
			if(rs.next())
			{
				agency.setano(rs.getString("ano"));
				agency.setaname(rs.getString("aname"));
				agency.setpwd(rs.getString("pwd"));
				agency.setasex(rs.getString("asex"));
				agency.setaphone(rs.getString("aphone"));
				agency.setaremark(rs.getString("aremark"));
			}
		}catch (SQLException e) {
			e.printStackTrace();
		}
		DbUtil.close();
		return agency;
	}
	
	
	public ArrayList<Agency> findAll(){
		ArrayList<Agency> AgencyList=new ArrayList<Agency>();
		String sqlSearch = "SELECT * FROM agency ORDER BY aname";
		ResultSet rs = null;
		rs = DbUtil.executeQuery(sqlSearch);
		try{
		while(rs.next())
		{
			 Agency tem= new Agency();
			 tem.setano(rs.getString("ano"));
			 tem.setaname(rs.getString("aname"));
			 tem.setpwd(rs.getString("pwd"));
			 tem.setasex(rs.getString("asex"));
			 tem.setaphone(rs.getString("aphone"));
			 tem.setaremark(rs.getString("aremark"));
			 AgencyList.add(tem);	 
		}
		DbUtil.close();
		}catch(SQLException e)
		{
			e.printStackTrace();	
		}			
		return AgencyList;		
	}
	
	public boolean login(String username,String password) {
		String sql = "SELECT count(*) AS NUM FROM agency WHERE aname = '"
				+ username + "'AND pwd = '" + password + "'";
		ResultSet rs = DbUtil.executeQuery(sql);
		int result = 0;
		try {
			if(rs.next())
			{
				result = rs.getInt("NUM");
			}
		}catch (SQLException e) {
			e.printStackTrace();
		}
		DbUtil.close();
		if(result>0)
			return true;
		else
			return false;
	}
}
