package henu.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import henu.bean.Buyer;
import henu.util.DbUtil;

public class BuyerDao
{
	public int save(Buyer buyer) {
		String sql = "INSERT INTO buyer(bno,bname,"
				+ "pwd,bsex,bphone)"
				+ "VALUES (?,?,?,?,?)";
		PreparedStatement ps = DbUtil.executePreparedStatement(sql);
		int result = 0;
		try {
			ps.setString(1,buyer.getbno());
			ps.setString(2,buyer.getbname());
			ps.setString(3,buyer.getpwd());
			ps.setString(4,buyer.getbsex());
			ps.setString(5,buyer.getbphone());
			result = ps.executeUpdate();
		}catch (SQLException e) {
			e.printStackTrace();
		}
		DbUtil.close();
		return result;
	}
	
	public int delete(String bno) {
		String sql = "DELETE FROM buyer WHERE bno = '"
				+ bno + "'";
		int result = 0;
		result = DbUtil.executeUpdate(sql);
		DbUtil.close();
		return result;
	}
	
	public int update(String bno,Buyer buyer) {
		String sql = "UPDATE buyer SET bname = ?,pwd = ?,bsex = ?,"
				+ " bphone = ?" + " WHERE bno = ?";
		PreparedStatement ps = DbUtil.executePreparedStatement(sql);
		int result = 0;
		try {
			ps.setString(1,buyer.getbname());
			ps.setString(2,buyer.getpwd());
			ps.setString(3,buyer.getbsex());
			ps.setString(4,buyer.getbphone());
			ps.setString(5,buyer.getbno());
			result = ps.executeUpdate();
			//System.out.println("result:" + result);
		}catch (SQLException e) {
			e.printStackTrace();
		}
		DbUtil.close();
		return result;
	}
	
	public Buyer findBybname(String bname) {
		String sql = "SELECT * FROM buyer WHERE bname = '"
				+ bname + "'";
		Buyer buyer =new Buyer();
		ResultSet rs = DbUtil.executeQuery(sql);
		try {
			if(rs.next())
			{
				buyer.setbno(rs.getString("bno"));
				buyer.setbname(rs.getString("bname"));
				buyer.setpwd(rs.getString("pwd"));
				buyer.setbsex(rs.getString("bsex"));
				buyer.setbphone(rs.getString("bphone"));
			}
		}catch (SQLException e) {
			e.printStackTrace();
		}
		DbUtil.close();
		return buyer;
	}
	
	
	public ArrayList<Buyer> findAll(){
		ArrayList<Buyer> BuyerList=new ArrayList<Buyer>();
		String sqlSearch = "SELECT * FROM buyer ORDER BY bname";
		ResultSet rs = null;
		rs = DbUtil.executeQuery(sqlSearch);
		try{
		while(rs.next())
		{
			 Buyer tem= new Buyer();
			 tem.setbno(rs.getString("bno"));
			 tem.setbname(rs.getString("bname"));
			 tem.setpwd(rs.getString("pwd"));
			 tem.setbsex(rs.getString("bsex"));
			 tem.setbphone(rs.getString("bphone"));
			 BuyerList.add(tem);
		}
		DbUtil.close();
		}catch(SQLException e)
		{
			e.printStackTrace();	
		}			
		return BuyerList;		
	}
	
	public boolean login(String username,String password) {
		String sql = "SELECT count(*) AS NUM FROM buyer WHERE bname = '"
				+ username + "'AND pwd = '" + password + "'";
		ResultSet rs = DbUtil.executeQuery(sql);
		int result = 0;
		try {
			if(rs.next())
			{
				result = rs.getInt("NUM");
			}
		}catch (SQLException e) {
			e.printStackTrace();
		}
		DbUtil.close();
		if(result>0)
			return true;
		else
			return false;
	}
}
