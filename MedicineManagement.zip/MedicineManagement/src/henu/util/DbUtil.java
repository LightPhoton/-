package henu.util;
import java.sql.*;


public class DbUtil {
	/**
	 * 声明连接数据库的信息，例如数据库URL、用户名及密码
	 */
	private static final String URL = "jdbc:mysql://localhost:3306/medidb?useUnicode=true&characterEncoding=utf8";
	private static final String USER = "root";
	private static final String PASSWORD = "";
	
	/**
	 * 声明JDBC的相关对象
	 */
	protected static Statement s = null;
	protected static ResultSet rs = null;
	protected static Connection conn = null;
	
	/**
	 * 创建数据库
	 * @return conn
	 */
	public static synchronized Connection getConnection()
	{
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(URL, USER, PASSWORD);
		}catch (Exception e) {
			e.printStackTrace();
		}
		return conn;
	}
	
	/**
	 * 执行INSERT、UPDATE、DELETE语句
	 * @param sql SQL语句，字符串类型
	 * @return 执行结果，int类型
	 */
	public static int executeUpdate(String sql)
	{
		int result = 0;
		try {
			s = getConnection().createStatement();
			result = s.executeUpdate(sql);
		}catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}
	
	/**
	 * 执行SELECT语句
	 * @param sql SQL语句，字符串类型
	 * @return ResultSet结果集
	 */
	public static ResultSet executeQuery(String sql)
	{
		try {
			s = getConnection().createStatement();
			rs = s.executeQuery(sql);
		}catch (SQLException e) {
			e.printStackTrace();
		}
		
		return rs;
	}
	
	
	public static StringBuffer agencyExecuteQuery(String sql)
	{
		try {
			s = getConnection().createStatement();
			rs = s.executeQuery(sql);
		}catch (SQLException e) {
			e.printStackTrace();
		}
		StringBuffer sb = new StringBuffer();
		try{
		//遍历查询结果，拼接成StringBuffer对象
			
			while(rs.next())
			{
				String ano="";				
				ano=rs.getString("ano");
				sb.append("<tr><td>");
				sb.append(rs.getString("ano"));
				sb.append("</td><td>");
				sb.append(rs.getString("aname"));
				sb.append("</td><td>");
				sb.append(rs.getString("pwd"));
				sb.append("</td><td>");
				sb.append(rs.getString("asex"));
				sb.append("</td><td>");
				sb.append(rs.getString("aphone"));
				sb.append("</td><td>");
				sb.append(rs.getString("aremark"));
				sb.append("</td><td>");
				//查询字符串，传递一个名为ano的参数，该参数的值为ano，即用户名
				sb.append("<a href = 'AgencyServlet?ano=" + ano + "&op=agencyDelete'>删除</a>");
				sb.append("&nbsp;");
				sb.append("<a href = 'page/agency/agencyUpdate.jsp?ano=" + ano + "'>修改</a>");
				sb.append("</td></tr>");
			}
		}catch (SQLException e)
		{
			e.printStackTrace();
		}
		
		return sb;
	}
	
	public static StringBuffer buyerExecuteQuery(String sql)
	{
		try {
			s = getConnection().createStatement();
			rs = s.executeQuery(sql);
		}catch (SQLException e) {
			e.printStackTrace();
		}
		StringBuffer sb = new StringBuffer();
		try{
		//遍历查询结果，拼接成StringBuffer对象
			
			while(rs.next())
			{
				String bno="";				
				bno=rs.getString("bno");
				sb.append("<tr><td>");
				sb.append(rs.getString("bno"));
				sb.append("</td><td>");
				sb.append(rs.getString("bname"));
				sb.append("</td><td>");
				sb.append(rs.getString("pwd"));
				sb.append("</td><td>");
				sb.append(rs.getString("bsex"));
				sb.append("</td><td>");
				sb.append(rs.getString("bphone"));
				sb.append("</td><td>");
				//查询字符串，传递一个名为bno的参数
				sb.append("<a href = 'BuyerServlet?bno=" + bno + "&op=buyerDelete'>删除</a>");
				sb.append("&nbsp;");
				sb.append("<a href = 'page/buyer/buyerUpdate.jsp?bno=" + bno + "'>修改</a>");
				sb.append("</td></tr>");
			}
		}catch (SQLException e)
		{
			e.printStackTrace();
		}
		
		return sb;
	}

	public static StringBuffer medicineExecuteQuery(String sql)
	{
		try {
			s = getConnection().createStatement();
			rs = s.executeQuery(sql);
		}catch (SQLException e) {
			e.printStackTrace();
		}
		StringBuffer sb = new StringBuffer();
		try{
		//遍历查询结果，拼接成StringBuffer对象
			
			while(rs.next())
			{
				String mno="";				
				mno=rs.getString("mno");
				sb.append("<tr><td>");
				sb.append(rs.getString("mno"));
				sb.append("</td><td>");
				sb.append(rs.getString("mname"));
				sb.append("</td><td>");
				sb.append(rs.getString("mmode"));
				sb.append("</td><td>");
				sb.append(rs.getString("mefficacy"));
				sb.append("</td><td>");
				//查询字符串，传递一个名为mno的参数
				sb.append("<a href = 'MedicineServlet?mno=" + mno + "&op=medicineDelete'>删除</a>");
				sb.append("&nbsp;");
				sb.append("<a href = 'page/medicine/medicineUpdate.jsp?mno=" + mno + "'>修改</a>");
				sb.append("</td></tr>");
			}
		}catch (SQLException e)
		{
			e.printStackTrace();
		}
		
		return sb;
	}
	
	public static StringBuffer clientExecuteQuery(String sql)
	{
		try {
			s = getConnection().createStatement();
			rs = s.executeQuery(sql);
		}catch (SQLException e) {
			e.printStackTrace();
		}
		StringBuffer sb = new StringBuffer();
		try{
		//遍历查询结果，拼接成StringBuffer对象
			
			while(rs.next())
			{
				String cno = "";
			    cno = rs.getString("cno");
			 	sb.append("<tr><td>");
			 	sb.append(cno);
			 	sb.append("</td><td>");
			 	sb.append(rs.getString("cname"));
			 	sb.append("</td><td>");
			 	sb.append(rs.getString("csex"));
			 	sb.append("</td><td>");
			 	sb.append(rs.getString("cage"));
			 	sb.append("</td><td>");
			 	sb.append(rs.getString("caddress"));
			 	sb.append("</td><td>");
			 	sb.append(rs.getString("cphone"));
			 	sb.append("</td><td>");
			 	sb.append(rs.getString("csymptom"));
			 	sb.append("</td><td>");
			 	sb.append(rs.getString("mno"));
			 	sb.append("</td><td>");
			 	sb.append(rs.getString("ano"));
			 	sb.append("</td><td>");
			 	sb.append(rs.getString("cdate"));
			 	sb.append("</td><td>");
			 	sb.append(rs.getString("cremark"));
			 	sb.append("</td><td>");
			 	//查询字符串，传递一个名为cno的参数，该参数的值为cno，即用户名
				sb.append("<a href = 'ClientServlet?cno=" + cno + "&op=clientDelete'>删除</a>");
				sb.append("&nbsp;");
				sb.append("<a href = 'page/client/clientUpdate.jsp?cno=" + cno + "'>修改</a>");
				sb.append("</td></tr>");
				
			}
		}catch (SQLException e)
		{
			e.printStackTrace();
		}
		
		return sb;
	}
	
	/**
	 * 执行动态SQL语句
	 * @param sql含有参数的动态SQL语句
	 * @return 返回PreparedStatement对象
	 */
	public static PreparedStatement executePreparedStatement(String sql)
	{
		PreparedStatement ps = null;
		try {
			ps = getConnection().prepareStatement(sql);
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return ps;
	}
	
	/**
	 * 事务回滚
	 */
	public static void rollback(){
		try {
			getConnection().rollback();
		}catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	
	/**
	 * 关闭数据库连接对象
	 */
	public static void close()
	{
		try{
			if(rs!=null)
				rs.close();
			if(s!=null)
				s.close();
			if(conn!=null)
				conn.close();
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
}
